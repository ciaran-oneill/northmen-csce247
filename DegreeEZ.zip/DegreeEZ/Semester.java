package DegreeEZ;

enum Semester {
    FALL,
    SPRING,
    SUMMER
}
