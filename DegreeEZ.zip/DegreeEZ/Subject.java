package DegreeEZ;

enum Subject {
    MATH,
    ECON,
    CSCE,
    ACCT,
    HIST,
    ANTH,
    SCIENCE,
    PSYCH
}